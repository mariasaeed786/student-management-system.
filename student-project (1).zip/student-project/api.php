<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

require 'db.php';

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"), true);

// 1. GET: Saare students ki list
if ($method === 'GET') {
    $result = $conn->query("SELECT * FROM students ORDER BY id DESC");
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    echo json_encode($students);
}

// 2. POST: Naya student add karna
if ($method === 'POST') {
    $name = $data['name'];
    $email = $data['email'];
    $phone = $data['phone'];
    $course = $data['course'];
    $status = $data['status'];

    $stmt = $conn->prepare("INSERT INTO students (name, email, phone, course, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $phone, $course, $status);
    
    if ($stmt->execute()) {
        echo json_encode(["message" => "Student added successfully"]);
    } else {
        echo json_encode(["error" => "Email already exists or error occurred"]);
    }
}

// 3. DELETE: Student delete karna
if ($method === 'DELETE') {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo json_encode(["message" => "Student deleted"]);
}

// 4. PUT: Student update karna
if ($method === 'PUT') {
    $id = $_GET['id'];
    $name = $data['name'];
    $email = $data['email'];
    $phone = $data['phone'];
    $course = $data['course'];
    $status = $data['status'];

    $stmt = $conn->prepare("UPDATE students SET name=?, email=?, phone=?, course=?, status=? WHERE id=?");
    $stmt->bind_param("sssssi", $name, $email, $phone, $course, $status, $id);
    $stmt->execute();
    echo json_encode(["message" => "Student updated"]);
}
?>