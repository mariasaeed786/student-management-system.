<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Management System</title>

    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Sidebar -->
    <aside class="sidebar">
        <h2>Student<span>Hub</span></h2>

        <nav>
            <a href="#dashboard" class="active">Dashboard</a>
            <a href="#students">Students</a>
            <a href="#add-student">Add Student</a>
            <a href="#registrations">Registrations</a>
        </nav>

                <div class="sidebar-bottom">
            <p style="color: #65c994; font-weight: bold; margin-bottom: 10px;">
                Welcome, <?php echo $_SESSION['user_name']; ?>! 
                (<?php echo ucfirst($_SESSION['user_role']); ?>)
            </p>
            <button onclick="logoutUser()" class="primary-btn" style="background: #a52a2a; width: 100%;">Logout</button>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">

        <!-- Header -->
        <header class="topbar">
            <div>
                <h1>Student Management System</h1>
                <p>Manage your students efficiently</p>
            </div>

            <div class="admin-profile">
                <div class="avatar">A</div>
                <div>
                    <strong>Admin</strong>
                    <p>Administrator</p>
                </div>
            </div>
        </header>

        <!-- Dashboard -->
        <section id="dashboard" class="section">
            <h2>Dashboard Overview</h2>

            <div class="stats-grid">
                <div class="stat-card">
                    <p>Total Students</p>
                    <h3 id="total-students">0</h3>
                    <span>Registered students</span>
                </div>

                <div class="stat-card">
                    <p>Recent Registrations</p>
                    <h3 id="recent-students">0</h3>
                    <span>Recently added</span>
                </div>

                <div class="stat-card">
                    <p>Active Students</p>
                    <h3 id="active-students">0</h3>
                    <span>Active records</span>
                </div>
            </div>
        </section>

        <!-- Student Management -->
        <section id="students" class="section">
            <div class="section-heading">
                <div>
                    <h2>Student Records</h2>
                    <p>View and manage all students</p>
                </div>

                        <?php if($_SESSION['user_role'] === 'admin'): ?>
            <a href="#add-student" class="primary-btn">
                + Add Student
            </a>
        <?php endif; ?>
            </div>

            <!-- Search -->
            <div class="search-area">
                <input
                    type="search"
                    id="search-input"
                    placeholder="Search by name, email or course..."
                    aria-label="Search students"
                >
                <button type="button" id="search-btn">
                    Search
                </button>
            </div>

            <!-- Students Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student Name</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody id="student-table-body">
                        <tr id="empty-message">
                            <td colspan="6">
                                No students found. Add your first student!
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
                        <!-- Pagination Controls -->
            <div id="pagination-controls" style="display: flex; justify-content: center; align-items: center; gap: 15px; margin-top: 20px;">
                <button type="button" id="prev-btn" class="secondary-btn" onclick="changePage(-1)">Previous</button>
                <span id="page-info" style="font-weight: bold; color: #176b45;">Page 1</span>
                <button type="button" id="next-btn" class="secondary-btn" onclick="changePage(1)">Next</button>
            </div>
        </section>

        <!-- Add Student Form -->
        <section id="add-student" class="section">
            <div class="section-heading">
                <div>
                    <h2>Add New Student</h2>
                    <p>Enter student information below</p>
                </div>
            </div>

            <form id="student-form">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="student-name">Full Name</label>
                        <input
                            type="text"
                            id="student-name"
                            name="name"
                            placeholder="Enter full name"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="student-email">Email Address</label>
                        <input
                            type="email"
                            id="student-email"
                            name="email"
                            placeholder="Enter email address"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="student-phone">Phone Number</label>
                        <input
                            type="tel"
                            id="student-phone"
                            name="phone"
                            placeholder="Enter phone number"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="student-course">Course</label>
                        <select id="student-course" name="course" required>
                            <option value="">Select a course</option>
                            <option value="Information Technology">
                                Information Technology
                            </option>
                            <option value="Computer Science">
                                Computer Science
                            </option>
                            <option value="Software Engineering">
                                Software Engineering
                            </option>
                            <option value="Business Administration">
                                Business Administration
                            </option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="student-status">Status</label>
                        <select id="student-status" name="status" required>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="reset" class="secondary-btn">
                        Clear Form
                    </button>

                    <button type="submit" class="primary-btn">
                        Save Student
                    </button>
                </div>
            </form>
        </section>

        <!-- Recent Registrations -->
        <section id="registrations" class="section">
            <h2>Recent Registrations</h2>
            <p>Newly registered students will appear in the student records.</p>
        </section>

        <!-- Footer -->
        <footer>
            <p>
                &copy; 2026 StudentHub. Student Management System.
            </p>
        </footer>

    </main>
        <!-- Pehle userRole define ho -->
    <script>
        const userRole = "<?php echo $_SESSION['user_role'] ?? 'user'; ?>"; 
    </script>

    <!-- Phir script.js load ho -->
    <script src="script.js"></script>

    <!-- Phir logout ka function -->
    <script>
    async function logoutUser() {
        await fetch('auth.php?action=logout');
        window.location.href = 'login.html';
    }
    </script>
</body>
</html>

