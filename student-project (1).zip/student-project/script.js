const studentForm = document.getElementById("student-form");
const studentTable = document.getElementById("student-table-body");
const searchInput = document.getElementById("search-input");

let students = []; // Yeh array ab database se aayega
let currentPage = 1;
const rowsPerPage = 5; // Ek page par kitne students dikhane hain
let editingId = null;
const API_URL = "api.php"; // Hamari PHP file ka rasta

// ==========================================
// 1. Database se data lana (READ)
// ==========================================
async function fetchStudents() {
    try {
        const response = await fetch(API_URL);
        students = await response.json();
        renderStudents();
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}

// ==========================================
// 2. Form Submit (Add / Update)
// ==========================================
studentForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const name = document.getElementById("student-name").value.trim();
    const email = document.getElementById("student-email").value.trim();
    const phone = document.getElementById("student-phone").value.trim();
    const course = document.getElementById("student-course").value;
    const status = document.getElementById("student-status").value;

    if (!name || !email || !phone || !course) {
        alert("Please fill in all fields.");
        return;
    }

    const studentData = { name, email, phone, course, status };

    try {
        if (editingId !== null) {
            // Update (PUT)
            const res = await fetch(`${API_URL}?id=${editingId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(studentData)
            });
            if (res.ok) alert("Student updated successfully!");
            editingId = null;
            document.querySelector("#student-form button[type='submit']").textContent = "Save Student";
        } else {
            // Add (POST)
            const res = await fetch(API_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(studentData)
            });
            const result = await res.json();
            if (result.error) {
                alert(result.error); // Agar email pehle se hai
                return;
            }
            alert("Student added successfully!");
        }

        studentForm.reset();
        fetchStudents(); // List ko refresh karein

    } catch (error) {
        console.error("Error saving student:", error);
    }
});

// ==========================================
// 3. Delete Student
// ==========================================
async function deleteStudent(id) {
    const confirmed = confirm("Are you sure you want to delete this student?");
    if (!confirmed) return;

    try {
        await fetch(`${API_URL}?id=${id}`, { method: "DELETE" });
        fetchStudents(); // List ko refresh karein
    } catch (error) {
        console.error("Error deleting:", error);
    }
}

// ==========================================
// 4. Edit Student (Form mein data dalna)
// ==========================================
function editStudent(id) {
    const student = students.find(item => item.id === id);
    if (!student) return;

    document.getElementById("student-name").value = student.name;
    document.getElementById("student-email").value = student.email;
    document.getElementById("student-phone").value = student.phone;
    document.getElementById("student-course").value = student.course;
    document.getElementById("student-status").value = student.status;

    editingId = id;
    document.querySelector("#student-form button[type='submit']").textContent = "Update Student";
    document.getElementById("add-student").scrollIntoView({ behavior: "smooth" });
}

// ==========================================
// 5. View Student Details
// ==========================================
function viewStudent(id) {
    const student = students.find(item => item.id === id);
    if (!student) return;
    alert(
        "Student Details\n\n" +
        "Name: " + student.name + "\n" +
        "Email: " + student.email + "\n" +
        "Phone: " + student.phone + "\n" +
        "Course: " + student.course + "\n" +
        "Status: " + student.status
    );
}

// ==========================================
// 6. UI Render (Table aur Dashboard)
// ==========================================
function renderStudents() {
    const query = searchInput.value.trim().toLowerCase();

    // 1. Pehle search filter lagayein
    const filteredStudents = students.filter(student =>
        student.name.toLowerCase().includes(query) ||
        student.email.toLowerCase().includes(query) ||
        student.course.toLowerCase().includes(query)
    );

    // 2. Pagination Logic
    const totalPages = Math.ceil(filteredStudents.length / rowsPerPage) || 1;
    
    // Agar current page total pages se bada ho jaye (maslan search karne par)
    if (currentPage > totalPages) currentPage = totalPages;

    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const paginatedStudents = filteredStudents.slice(startIndex, endIndex);

    // 3. UI Update karein
    studentTable.replaceChildren();

    if (paginatedStudents.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");
        cell.colSpan = 6;
        cell.textContent = students.length === 0
            ? "No students found. Add your first student!"
            : "No matching students found.";
        row.appendChild(cell);
        studentTable.appendChild(row);
    }

    paginatedStudents.forEach(student => {
        const row = document.createElement("tr");
        const values = [student.id, student.name, student.email, student.course];
        
        values.forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        const statusCell = document.createElement("td");
        const statusBadge = document.createElement("span");
        statusBadge.className = student.status === "Active" ? "status" : "status inactive";
        statusBadge.textContent = student.status;
        statusCell.appendChild(statusBadge);
        row.appendChild(statusCell);

        const actionsCell = document.createElement("td");

        const viewButton = createButton("View", "action-btn");
        viewButton.addEventListener("click", () => viewStudent(student.id));
        actionsCell.appendChild(viewButton);

        // Sirf Admin ke liye Edit/Delete
        if (userRole === 'admin') {
            const editButton = createButton("Edit", "action-btn edit-btn");
            editButton.addEventListener("click", () => editStudent(student.id));
            const deleteButton = createButton("Delete", "action-btn delete-btn");
            deleteButton.addEventListener("click", () => deleteStudent(student.id));
            actionsCell.append(editButton, deleteButton);
        }

        row.appendChild(actionsCell);
        studentTable.appendChild(row);
    });

    // 4. Pagination Buttons Update karein
    document.getElementById("page-info").textContent = `Page ${currentPage} of ${totalPages}`;
    document.getElementById("prev-btn").disabled = currentPage === 1;
    document.getElementById("next-btn").disabled = currentPage === totalPages;

    // Agar sirf 1 page hai toh buttons chhupa dein
    if (totalPages <= 1) {
        document.getElementById("pagination-controls").style.display = "none";
    } else {
        document.getElementById("pagination-controls").style.display = "flex";
    }

    updateDashboard();
}

function createButton(text, className) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = text;
    button.className = className;
    return button;
}

function updateDashboard() {
    document.getElementById("total-students").textContent = students.length;
    document.getElementById("active-students").textContent = students.filter(s => s.status === "Active").length;
    
    // Recent registrations (Aaj ke din add hone wale)
    const today = new Date().toISOString().split('T')[0];
    const recentCount = students.filter(student => student.created_at && student.created_at.startsWith(today)).length;
    document.getElementById("recent-students").textContent = recentCount;
}

// Search input event
searchInput.addEventListener("input", renderStudents);

// Page load hone par data fetch karein
fetchStudents();
// Pagination Next/Prev Buttons
function changePage(direction) {
    currentPage += direction;
    renderStudents();
}